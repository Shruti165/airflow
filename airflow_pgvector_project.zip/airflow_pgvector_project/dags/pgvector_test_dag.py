from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime
import numpy as np

# Function to create table with pgvector column
def create_table():
    pg_hook = PostgresHook(postgres_conn_id="postgres_default")
    sql = """
    CREATE TABLE IF NOT EXISTS test_vectors (
        id SERIAL PRIMARY KEY,
        embedding VECTOR(3),
        description TEXT
    );
    """
    pg_hook.run(sql)

# Function to insert vector data
def insert_vectors():
    pg_hook = PostgresHook(postgres_conn_id="postgres_default")
    sql = """
    INSERT INTO test_vectors (embedding, description)
    VALUES (%s, %s);
    """
    vectors = [
        (np.array([0.1, 0.2, 0.3]).tolist(), "Vector 1"),
        (np.array([0.4, 0.5, 0.6]).tolist(), "Vector 2"),
        (np.array([0.7, 0.8, 0.9]).tolist(), "Vector 3"),
    ]
    pg_hook.run_many(sql, vectors)

# Function to query vectors for similarity
def query_vectors():
    pg_hook = PostgresHook(postgres_conn_id="postgres_default")
    sql = """
    SELECT id, embedding, description
    FROM test_vectors
    ORDER BY embedding <-> %s
    LIMIT 1;
    """
    query_vector = [0.3, 0.3, 0.3]
    result = pg_hook.get_records(sql, parameters=(query_vector,))
    for row in result:
        print(f"Closest Vector: ID={row[0]}, Embedding={row[1]}, Description={row[2]}")

# Default arguments
default_args = {
    "owner": "airflow",
    "start_date": datetime(2023, 1, 1),
    "retries": 1,
}

# DAG definition
with DAG(
    dag_id="pgvector_test_dag",
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
) as dag:

    task_create_table = PythonOperator(
        task_id="create_pgvector_table",
        python_callable=create_table,
    )

    task_insert_vectors = PythonOperator(
        task_id="insert_vector_data",
        python_callable=insert_vectors,
    )

    task_query_vectors = PythonOperator(
        task_id="query_similar_vectors",
        python_callable=query_vectors,
    )

    # Task dependencies
    task_create_table >> task_insert_vectors >> task_query_vectors
