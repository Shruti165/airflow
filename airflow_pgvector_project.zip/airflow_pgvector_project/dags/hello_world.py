# hello_world.py

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime

# Function to print Hello World
def print_hello():
    print("Hello, World!")

# Define the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 12, 9),
    'retries': 1,
}

dag = DAG(
    'hello_world_dag',
    default_args=default_args,
    description='A simple Hello World DAG',
    schedule_interval=None,  # Set this to None for manual trigger
)

# Define the task
hello_task = PythonOperator(
    task_id='hello_task',
    python_callable=print_hello,
    dag=dag,
)

hello_task
