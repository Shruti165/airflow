from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import psycopg2

def insert_vector():
    conn = psycopg2.connect(
        dbname="airflow_db",
        user="airflow",
        password="airflow",
        host="postgres_with_pgvector",
        port=5432
    )
    cursor = conn.cursor()
    cursor.execute("CREATE EXTENSION IF NOT EXISTS vector;")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS embeddings (
            id SERIAL PRIMARY KEY,
            embedding VECTOR(3)
        );
    """)
    cursor.execute("INSERT INTO embeddings (embedding) VALUES ('[0.1, 0.2, 0.3]');")
    conn.commit()
    cursor.close()
    conn.close()

with DAG(
    dag_id="example_vector_dag",
    default_args={"start_date": datetime(2023, 1, 1)},
    schedule_interval=None,
    catchup=False,
) as dag:
    insert_task = PythonOperator(
        task_id="insert_vector",
        python_callable=insert_vector,
    )
