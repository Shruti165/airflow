docker-compose build
docker-compose up -d

Verify PostgreSQL and pgvector: Access the PostgreSQL container:
docker exec -it postgres_with_pgvector psql -U airflow -d airflow_db
CREATE EXTENSION IF NOT EXISTS vector;

Access Airflow Web Interface: Open http://localhost:18080 in your browser.

Deploy and Test DAGs: Place your DAGs in the dags/ directory, and they’ll be automatically loaded by Airflow.

docker exec -it postgres_with_pgvector psql -U airflow -d airflow_db
SELECT dag_id, is_paused FROM dag;

SELECT dag_id, run_id, state, execution_date, start_date, end_date FROM dag_run ORDER BY execution_date DESC;
